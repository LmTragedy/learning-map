r"""Read-only check: stage spread per material, and how fair-allocation nodes are linked.

Run from the repository root:  .venv\Scripts\python.exe path\to\inspect_stages.py [course-title-part] [material-name ...]
Defaults: course 'comp4418', topic materials 'FairAllocations_week7.pdf' 'Week 8 - Slides.pdf'.
"""
import json
import sqlite3
import sys
from collections import Counter

sys.path.insert(0, ".")
from backend.route import learning_route  # noqa: E402

course_key = sys.argv[1] if len(sys.argv) > 1 else "comp4418"
topic = set(sys.argv[2:]) or {"FairAllocations_week7.pdf", "Week 8 - Slides.pdf"}
db = sqlite3.connect("file:data/learning.sqlite3?mode=ro", uri=True)
course = json.loads(next(body for (body,) in db.execute("SELECT body FROM courses WHERE deleted = 0") if course_key in body))
names = {m["id"]: m["name"] for m in course["materials"]}
nodes, edges = course["nodes"], course.get("edges", [])
by_id = {n["id"]: n for n in nodes}
route = learning_route(nodes)
stage_of = {nid: s["title"] for s in route.get("stages", []) for nid in s["node_ids"]}
# Per-topic stages, if the new route shape exists.
for t in route.get("topics", []):
    print("topic", t.get("name"), [(s["title"], len(s["node_ids"])) for s in t["stages"]])

print("course:", len(nodes), "nodes,", len(edges), "edges")
print("stages:", [(s["title"], len(s["node_ids"])) for s in route.get("stages", [])])
for material in course["materials"]:
    group = [n for n in nodes if material["id"] in {s["material_id"] for s in n["sources"]}]
    print(f"  {material['name']} (topic={material.get('topic_id', '-')}): {len(group)} nodes,",
          dict(Counter(stage_of.get(n["id"]) for n in group)))

ids = {n["id"] for n in nodes if any(names.get(s["material_id"]) in topic for s in n["sources"])}
inner = [e for e in edges if e["source"] in ids and e["target"] in ids]
cross = [e for e in edges if (e["source"] in ids) != (e["target"] in ids)]
print("\ntopic nodes:", len(ids), "| with prerequisites:", sum(1 for i in ids if by_id[i]["prerequisites"]),
      "| prerequisite refs:", sum(len(by_id[i]["prerequisites"]) for i in ids))
print("inner edges:", len(inner), dict(Counter(e.get("relation") for e in inner)))
print("cross-topic edges:", len(cross))
for e in cross:
    print("   ", by_id[e["source"]]["title"], "→", by_id[e["target"]]["title"], f"({e.get('relation')})")
