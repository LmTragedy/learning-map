import sqlite3, json, sys
db = sqlite3.connect("file:data/learning.sqlite3?mode=ro", uri=True)
c = json.loads([r[0] for r in db.execute("SELECT body FROM courses") if 'comp4418' in r[0]][0])
mats = {m["id"]: m["name"] for m in c["materials"]}
fa = {"Week 8 - Slides.pdf", "FairAllocations_week7.pdf"}
done = {n["id"] for n in c["nodes"] if n["status"] in ("mastered", "passed")}
nodes = [dict(id=n["id"], title=n["title"], status=n["status"],
              unlocked=set(n.get("prerequisites", [])) <= done,
              topic="fa" if all(mats.get(s["material_id"]) in fa for s in n["sources"]) else "gt") for n in c["nodes"]]
edges = [dict(source=e["source"], target=e["target"], optional=(e.get("strength") != "required") if e.get("strength") else e.get("kind") != "用到") for e in c["edges"]]
json.dump(dict(nodes=nodes, edges=edges), open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False)
print(sum(n["unlocked"] for n in nodes), len(nodes), len(edges))
