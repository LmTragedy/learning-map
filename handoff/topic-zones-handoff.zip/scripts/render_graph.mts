import { readFileSync, writeFileSync } from "node:fs";
// Copy frontend/src/graphLayout.ts next to this file first.
import { forceLayout } from "./graphLayout.ts";
const dir = process.argv[2];
const { nodes, edges } = JSON.parse(readFileSync(`${dir}/graph.json`, "utf8"));
const byId = new Map(nodes.map((n: any) => [n.id, n]));
const degree = new Map<string, number>();
for (const e of edges) for (const k of [e.source, e.target]) degree.set(k, (degree.get(k) ?? 0) + 1);
const tone = (n: any) => n.status === "passed" ? "#4ade80" : n.status === "mastered" ? "#60a5fa" : n.status === "studied" ? "#a1a1aa" : n.unlocked ? "#fbbf24" : "#71717a";
const radius = (id: string) => Math.round(5 + Math.sqrt(degree.get(id) ?? 0) * 2.4);

function draw(pos: Map<string, { x: number; y: number }>, boxes: { name: string; count: number; x0: number; y0: number; x1: number; y1: number }[]) {
  let xs = [...pos.values()].map((p) => p.x), ys = [...pos.values()].map((p) => p.y);
  for (const b of boxes) { xs.push(b.x0, b.x1); ys.push(b.y0, b.y1); }
  const pad = 30, minX = Math.min(...xs) - pad, minY = Math.min(...ys) - pad, w = Math.max(...xs) - minX + pad, h = Math.max(...ys) - minY + pad;
  const out = [`<svg viewBox="${minX.toFixed(0)} ${minY.toFixed(0)} ${w.toFixed(0)} ${h.toFixed(0)}">`,
    `<rect x="${minX}" y="${minY}" width="${w}" height="${h}" fill="#09090b"/>`];
  for (const b of boxes) {
    out.push(`<rect x="${b.x0}" y="${b.y0}" width="${b.x1 - b.x0}" height="${b.y1 - b.y0}" rx="28" fill="#ffffff" fill-opacity="0.018" stroke="#52525b" stroke-width="1.2" stroke-dasharray="6 6"/>`);
    out.push(`<text x="${b.x0 + 20}" y="${b.y0 + 26}" fill="#a1a1aa" font-size="13" font-weight="700">${b.name}<tspan fill="#71717a" font-weight="400" dx="8">${b.count} 个知识点</tspan></text>`);
  }
  out.push(`<g stroke="#71717a" stroke-width="1" fill="none" stroke-opacity="0.6">`);
  for (const e of edges) {
    const a = pos.get(e.source), b = pos.get(e.target); if (!a || !b) continue;
    out.push(`<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"${e.optional ? ' stroke-dasharray="4 3"' : ""}/>`);
  }
  out.push(`</g>`);
  for (const [id, p] of pos) out.push(`<circle cx="${p.x}" cy="${p.y}" r="${radius(id)}" fill="${tone(byId.get(id))}" stroke="#09090b" stroke-width="2"/>`);
  out.push(`</svg>`);
  return out.join("\n");
}

const now = forceLayout(nodes, edges);
const topics = [{ key: "gt", name: "博弈论" }, { key: "fa", name: "公平分配" }];
const after = new Map<string, { x: number; y: number }>();
const boxes: any[] = [];
let cursor = 0;
for (const t of topics) {
  const tn = nodes.filter((n: any) => n.topic === t.key);
  const ids = new Set(tn.map((n: any) => n.id));
  const pos = forceLayout(tn, edges.filter((e: any) => ids.has(e.source) && ids.has(e.target)));
  const xs = [...pos.values()].map((p) => p.x), ys = [...pos.values()].map((p) => p.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs), cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  const P = 40, top = 34;
  for (const [id, p] of pos) after.set(id, { x: Math.round(p.x - minX + cursor + P), y: Math.round(p.y - cy) });
  const bx0 = cursor, bx1 = cursor + (maxX - minX) + 2 * P;
  boxes.push({ name: t.name, count: tn.length, x0: bx0, x1: Math.round(bx1), y0: Math.round(Math.min(...ys) - cy - P - top), y1: Math.round(Math.max(...ys) - cy + P) });
  cursor = bx1 + 56;
}
// Same box height for both, so the pair reads as one row.
const y0 = Math.min(...boxes.map((b) => b.y0)), y1 = Math.max(...boxes.map((b) => b.y1));
for (const b of boxes) { b.y0 = y0; b.y1 = y1; }
writeFileSync(`${dir}/graph-now.svg`, draw(now, []));
writeFileSync(`${dir}/graph-after.svg`, draw(after, boxes));
const cross = edges.filter((e: any) => byId.get(e.source)?.topic !== byId.get(e.target)?.topic).length;
console.log("ok cross edges", cross, boxes.map((b) => [b.name, b.x0, b.x1, b.y0, b.y1]));
