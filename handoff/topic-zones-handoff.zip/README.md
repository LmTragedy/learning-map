# 任务：主题分区 + 补先修（learning-map）

仓库：`D:\记忆库\learning-map`（FastAPI 后端 `backend/`，React + Vite 前端 `frontend/`，数据在 `data/learning.sqlite3`）。
本包里的设计报告 `design-report.html` 是和用户确认过的方案，界面示意以它为准。

---

## 0. 开工前必读

- **工作区有大量未提交改动**（另一个对话做的：教学计划、AI 任务写回、`existing:ID` 引用等）。开工前先 `git status` / `git diff`，在这些改动之上继续，不要回退、不要覆盖。其中 `backend/learning.py` 的 `_existing_map_references`、`_map_catalog` 和 `backend/schemas.py` 的 `valid_reference` 都还是未提交代码，本任务依赖它们。
- **保留现有视觉风格。** 用户明确拒绝过重新设计，也拒绝了"泳道"式关系图。只在现有界面上加结构：沿用现有颜色、组件、分组样式（参见 `docs/design-language.md`）。
- AI 写入的内容一律标 `uncertain=True`，显示为"待核对"。**不覆盖用户的人工编辑，不删除已有先修。**
- 界面文案用中文，写法跟现有界面一致。

## 1. 问题与诊断（已用真实数据核实）

现象：课程 comp4418 新加的两份 PDF（`FairAllocations_week7.pdf`、`Week 8 - Slides.pdf`）的节点几乎全在"阶段 1"，和前面博弈论的内容也几乎没有关联。

阶段的算法见 `backend/route.py`：只看 `node["prerequisites"]` 做拓扑排序，`depth // 2` 就是阶段编号；**relations 完全不参与**。

数据（2026-11-04，只读查询；脚本在 `scripts/`）：

| 指标 | 数值 |
|---|---|
| 课程总量 | 88 个节点，110 条边 |
| 公平分配节点（任一来源是 week7/8） | 35 个，其中 33 个在阶段 1 |
| 有先修的公平分配节点 | 5 个，共 6 条先修引用 |
| 公平分配内部的边 | 35 条：工具关系 19、帮助理解 6、相似或对比 5、前置（AI 推断）5 |
| 公平分配 ↔ 博弈论的边 | 2 条，都经由"帕累托"这个跨材料合并的节点 |

根因：
1. **依赖关系被写进了 relations，而不是 prerequisites。** 生成 prompt（`backend/learning.py` 的 `_generate`，约 597–612 行）里写着"需要回连旧节点时用relations表达"，会主动引导 AI 这样做。而且 `_append_prerequisites`（约 425 行）只给**新**节点写先修，"旧节点 → 新节点"方向的依赖没有地方落地。
2. **跨主题该有的先修漏了。** 一次 prompt 塞了 426 页材料、几十个新节点和完整的旧目录，AI 没有逐个对照。应该存在的例子：效用函数与偏好表示 → 可加估值与物品束价值；主体与偏好关系 / 理性偏好 → 序数偏好、字典序偏好；彩票 / vNM 期望效用 → 随机分配的概率矩阵、随机占优；占优行动 → 策略真实性。
3. **阶段是全课程统一算的。** 一个新主题的起点本来就没有先修，必然和博弈论的起点挤在阶段 1。

明显应该是先修、却被写成了普通关系的例子：可加估值 → 无嫉妒 → EF1 → 嫉妒循环 / 轮转选取；MMS → 近似 MMS；随机分配概率矩阵 → PS；序列独裁 → RSD。

## 2. 已确定的设计

- **主题（topic）是课程的一层结构。** 主题由用户指定，不交给 AI 判断（上传时可以让 AI 推荐一个名字，但要用户确认）。
  - `course.topics = [{id, name, color, order}]`
  - `material.topic_id`：每份材料只属于一个主题。
  - 节点的主题是推导出来的，不单独存：取它的来源里，在 `course.materials` 中排得最早的那份材料所在的主题。
- **迁移：** 课程没有 `topics` 时，视为只有一个主题"全部材料"，包含所有材料。这时的所有行为（列表、阶段、关系图）必须和现在**完全一致**。
- **阶段按主题分别计算。** 只用主题内的先修算深度。跨主题的先修不增加深度，作为"入口依赖"输出。
- **解锁规则不变**：跨主题的先修仍然要先通过才解锁。
- **列表**（`frontend/src/CourseMap.tsx` 的 `RouteList`，约 141–146 行）：没有主线时按"主题 → 阶段"两层分组，主题标题沿用主线分组的彩色竖条样式；有主线时保持现状。
- **关系图**：保留现有力导向布局。每个主题用 `forceLayout` 单独跑一次，结果横向并排，主题之间留 56px 间距，每个主题外面画一个淡虚线框。效果见 `mockups/graph-after.png`，参考实现见 `scripts/render_graph.mts`。
  - 虚线框：`rx=28`，`stroke #52525b`，`stroke-dasharray 6 6`，`stroke-width 1.2`，填充 `#fff` 不透明度 0.018。
  - 框左上角标签："主题名"（#a1a1aa，13px，加粗）加"N 个知识点"（#71717a）。
  - 跨主题的线和普通连线样式相同。
  - 只有 1 个主题时不画框。
- **节点面板**：跨主题的先修标签前面加主题名，例如"博弈论 · 效用函数与偏好表示"。

## 3. 实施清单

### P1 补先修（最先做，对现有数据立即见效）
1. **改 prompt。** `learning.py` `_generate`：删掉"需要回连旧节点时用relations表达"，改成"依赖关系一律写进 prerequisites（本批 key 或 existing:ID）；relations 只用于不影响学习顺序的联系"。
2. **前置知识并入先修。** `_append_generated_relations`：relation 为"前置知识"的边，把 source 追加到 target 的 prerequisites（target 可以是旧节点，只追加、不删除），追加前用 `_has_cycle` 检查，成环就不加。同时把这条边的 `controls_unlock` 设为 True。
3. **新增 AI 任务"补先修"**（kind 例如 `prerequisites`）。写法可以参考 `backend/node_links.py`（任务框架 `learning.tasks.run(...)`、`structured(...)`、`store.edit(...)`、先 `snapshot` 再写）。
   - 每批约 10 个节点。默认处理没有先修的节点，也可以指定某个主题。
   - **输入**：
     - 本批节点的标题、完整摘要、块、步骤；
     - 同主题全部节点的 `existing:ID`、标题、200 字以内摘要；
     - 其它主题的节点只给 ID、标题、一句话摘要；
     - 本批节点已有的 relations，让 AI 判断其中哪些其实是先修。
   - **输出 schema**：`[{node, prerequisites:[{ref, reason, uncertain}], independent_reason}]`。`ref` 只能是给出的 `existing:ID`，不能是节点自己，也不能成环。
   - **写回**：
     - 追加到 prerequisites，并新增一条边：`relation="前置（AI 推断）"`，`uncertain=True`，`controls_unlock=True`，`origin="ai_prereqs"`，`explanation` 写 reason；
     - 如果已有同向的边，就更新那条边、不要重复建；
     - 已有反向的边时跳过。
   - **触发**：地图生成完成后自动跑一次，处理本次新加的节点；资料面板或地图工具栏另加一个"补先修"按钮，前端调用方式参照 `api.ts` 里现有的 AI 任务。
   - 写测试：用假 AI 回复，覆盖成环拒绝、不覆盖人工编辑、旧节点可以追加先修。

### P2 主题数据 + 列表
- `schemas.py` 的 `MaterialUpdate` 加 `topic_id`；`app.py:254` 的 `update_material` / `files.py:148` 的 `update_material_info` 支持写入它。
- 新增主题的增删改和排序接口：只有空主题可以删；新建时自动分配颜色。
- `route.py`：
  - 按主题输出 `route.topics = [{id, name, color, stages:[{id, title, node_ids}], entry_dependencies}]`；
  - **同时保留**扁平的 `route.stages`，按主题顺序拼接、stage id 带主题前缀，因为 `handoff.py:41` 依赖它的顺序；
  - "建议接着学"（`next_node_id`）优先在进行中的主题里找。
- `domain.py` `project_course`：没有 `topics` 时投影出默认主题。
- 前端：
  - `types.ts`、`api.ts`；
  - `MaterialsPanel.tsx`：每份材料加主题下拉（可以新建、改名、调整顺序），上传时默认选上一份材料的主题；
  - `CourseMap.tsx` `RouteList`：两层分组；
  - `NodePanel.tsx`：先修标签带主题名。

### P3 关系图虚线框
- `MapView.tsx:117` 现在是 `forceLayout(course.nodes, links)`。改成按主题分组：每组用组内的 links 单独布局，再横向平移拼起来。框作为 React Flow 背景层、或者 group 节点来画。
- 只有一个主题时走原来的逻辑，结果必须完全一样。`frontend/tests/graphLayout.test.mjs` 要继续通过，新逻辑补测试。

### P4 按主题生成
- `_generate`：新材料属于主题 T 时，prompt 里给 T 的完整节点目录、其它主题的精简目录；生成完自动接 P1 的补先修。

## 4. 验收标准
- `.venv\Scripts\python.exe -m pytest` 全部通过；`cd frontend; npm run build`、`npm run lint` 通过；`node --test frontend/tests/*.test.mjs` 通过。
- 只有一个主题时，列表、阶段、关系图和改动前完全一致（加回归测试）。
- 在用户的真实数据上（先备份 `data/`，或者用 `store.snapshot`）：
  - 把 GT I + II 归入"博弈论"、week7 + 8 归入"公平分配"，再跑一次补先修；
  - 用 `scripts/inspect_stages.py` 复查：公平分配主题内至少分出 3 个阶段，第 1 节列出的跨主题先修大部分能补上。
  - 结果给用户看，等用户确认；不要擅自改掉 `uncertain` 标记。
- 在运行中的应用里（`http://127.0.0.1:8741/`，或者 `.claude/launch.json` 里的 `frontend-dev`）截图验证列表分组、关系图虚线框、资料面板下拉、节点面板标签。

## 5. 设计报告里留给用户决定的问题（先按建议默认实现，并告诉用户）
- 跨主题先修是否卡解锁 → 建议：卡，节点上写明原因，可以用现有的"直达"临时打开。
- 主题顺序由谁定 → 建议：默认按材料上传顺序，用户可以调整。
- 阶段要不要小标题 → 建议：可选，补先修时让 AI 起名并标为待核对；做不完可以先不做。

## 6. 包内文件
- `design-report.html`：完整设计报告，包括诊断、数据图表和界面示意。浏览器直接打开。
- `mockups/graph-now.png`、`mockups/graph-after.png`：用 `graphLayout.ts` 在真实数据上渲染的关系图，现在 vs 加虚线框后。
- `scripts/inspect_stages.py`：只读统计各材料的阶段分布、公平分配的边类型和跨主题边（在仓库根目录运行）。
- `scripts/dump_graph.py` + `scripts/render_graph.mts`：导出图数据，并按主题分组画虚线框的参考实现（`node render_graph.mts <dir>`，需要先把 `frontend/src/graphLayout.ts` 复制到同一目录）。
